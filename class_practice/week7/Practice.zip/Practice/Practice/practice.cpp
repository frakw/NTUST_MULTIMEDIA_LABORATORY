#include <opencv2/opencv.hpp>
#include<iostream>
using namespace std;
using namespace cv;

int Sobel_X[3][3] = { 
	{-1, 0, 1 }, 
	{-2, 0, 2}, 
	{-1, 0, 1} };
int Sobel_Y[3][3] = { 
	{ -1, -2, -1 },
	{ 0, 0, 0 },
	{ 1, 2, 1 } };

int main()
{
	Mat img = imread("pikachu.png");

	Mat gary;
	cvtColor(img, gary, cv::COLOR_BGR2GRAY); //��Ƕ�
	Mat edge_img = Mat::zeros(img.rows, img.cols, CV_8UC1);
	int T = 150; // ���e��

	imshow("edge_img", edge_img);
	waitKey(0);	
}