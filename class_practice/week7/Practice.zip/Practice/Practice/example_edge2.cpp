//#include <opencv2/opencv.hpp>
//using namespace cv;
//
//int main() {
//	Mat src = imread("pikachu.png", 0);
//	GaussianBlur(src, src, Size(3, 3), 0, 0);
//	Mat dst1;
//	Canny(src, dst1, 50, 150);
//	imshow("origin", src);
//	imshow("Canny_1", dst1);
//	waitKey(0);
//
//	return 0;
//}